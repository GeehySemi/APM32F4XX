
#include "usbd_class_msc.h"
#include "usbd_init.h"



void USBD_MSC_Init(void);

